# Đồ Án Cuối Môn
## Thông tin Đồ Án
### LẬP TRÌNH PHẦN MỀM QUẢN LÝ BÁN HÀNG CAFÉ

* DataBase: MS-SQL
* Backend: Window form 3 lớp
* FrontEnd: Window form
* Ngôn ngữ: C#, SQL


## Thông tin Nhóm

### Thành Viên 1
* Họ Tên: Lục Cẩm Sơn
* mssv: 2310060066
* Mã lớp: 23TXTH01

### Thành Viên 2
* Họ Tên: Lê Đình Quý
* mssv: 2310060019
* Mã lớp: 23TXTH01

### Thành Viên 3
* Họ Tên: Lý Vĩnh Thiên Quý
* mssv: 2310060058
* Mã lớp: 23TXTH01

### Thành Viên 4
* Họ Tên: Trần Võ Thảo Nguyên
* mssv: 2310060046
* Mã lớp: 23TXTH01

## Thông tin cấu trúc folder


### Folder "datasource" chứa data đồ án trong folder chứa

* 1 file QUANCAFEDB.sql
* Note: import data trước khi run chương trình

### Folder "source" chứa bài làm source code trong folder chứa

* Chứa folder "QL_CAFE" gồm tất cả chương trình 3 lớp
* Note: trước khi run chương trình vào file path: ".\QL_CAFE\QL_CAFE\DAO\DataProvider.cs" tại dòng "private string connectionSTR =" thay connection của database trước khi chạy

### Folder "PIC" chứa hình đồ án gồm:

* Folder "Pic" chứa hình chụp kết quả bài làm
