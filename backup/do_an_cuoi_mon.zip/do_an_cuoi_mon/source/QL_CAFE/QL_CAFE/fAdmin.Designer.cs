﻿namespace QL_CAFE
{
    partial class fAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tcBill = new TabControl();
            tpBill = new TabPage();
            panel3 = new Panel();
            btnViewBill = new Button();
            dtpkToDate = new DateTimePicker();
            label2 = new Label();
            dtpkFromDate = new DateTimePicker();
            panel4 = new Panel();
            dtgvBill = new DataGridView();
            tpDrink = new TabPage();
            panel6 = new Panel();
            txbSearchName = new TextBox();
            btnSearchDrink = new Button();
            panel5 = new Panel();
            panel10 = new Panel();
            nmDrinkPrice = new NumericUpDown();
            label5 = new Label();
            panel9 = new Panel();
            cbDrinkCategory = new ComboBox();
            label4 = new Label();
            panel8 = new Panel();
            txbDrinkName = new TextBox();
            label3 = new Label();
            panel7 = new Panel();
            txbDrinkID = new TextBox();
            label1 = new Label();
            panel2 = new Panel();
            btnShowDrink = new Button();
            btnEditDrink = new Button();
            btnDeleteDrink = new Button();
            btnAddDrink = new Button();
            panel1 = new Panel();
            dtgvDrink = new DataGridView();
            tpDrinkCategory = new TabPage();
            panel12 = new Panel();
            panel15 = new Panel();
            txbCategoryName = new TextBox();
            label8 = new Label();
            panel16 = new Panel();
            txbCategoryID = new TextBox();
            label9 = new Label();
            panel17 = new Panel();
            btnShowCategory = new Button();
            btnEditCategory = new Button();
            btnDeleteCategory = new Button();
            btnAddCategory = new Button();
            panel18 = new Panel();
            dtgvCategory = new DataGridView();
            tpTable = new TabPage();
            panel11 = new Panel();
            panel21 = new Panel();
            txbTableStatus = new TextBox();
            label10 = new Label();
            panel13 = new Panel();
            txbTableName = new TextBox();
            label6 = new Label();
            panel14 = new Panel();
            txbTableID = new TextBox();
            label7 = new Label();
            panel19 = new Panel();
            btnShowTable = new Button();
            btnEditTable = new Button();
            btnDeleteTable = new Button();
            btnAddTable = new Button();
            panel20 = new Panel();
            dtgvTable = new DataGridView();
            tpAccount = new TabPage();
            panel22 = new Panel();
            btnResetPass = new Button();
            panel23 = new Panel();
            numericUpDown1 = new NumericUpDown();
            label11 = new Label();
            panel24 = new Panel();
            txbDislplayName = new TextBox();
            label12 = new Label();
            panel25 = new Panel();
            txbUserName = new TextBox();
            label13 = new Label();
            panel26 = new Panel();
            btnShowAccount = new Button();
            btnEditAccount = new Button();
            btnDeleteAccount = new Button();
            btnAddAccount = new Button();
            panel27 = new Panel();
            dtgvAccount = new DataGridView();
            tcBill.SuspendLayout();
            tpBill.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dtgvBill).BeginInit();
            tpDrink.SuspendLayout();
            panel6.SuspendLayout();
            panel5.SuspendLayout();
            panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nmDrinkPrice).BeginInit();
            panel9.SuspendLayout();
            panel8.SuspendLayout();
            panel7.SuspendLayout();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dtgvDrink).BeginInit();
            tpDrinkCategory.SuspendLayout();
            panel12.SuspendLayout();
            panel15.SuspendLayout();
            panel16.SuspendLayout();
            panel17.SuspendLayout();
            panel18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dtgvCategory).BeginInit();
            tpTable.SuspendLayout();
            panel11.SuspendLayout();
            panel21.SuspendLayout();
            panel13.SuspendLayout();
            panel14.SuspendLayout();
            panel19.SuspendLayout();
            panel20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dtgvTable).BeginInit();
            tpAccount.SuspendLayout();
            panel22.SuspendLayout();
            panel23.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            panel24.SuspendLayout();
            panel25.SuspendLayout();
            panel26.SuspendLayout();
            panel27.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dtgvAccount).BeginInit();
            SuspendLayout();
            // 
            // tcBill
            // 
            tcBill.Controls.Add(tpBill);
            tcBill.Controls.Add(tpDrink);
            tcBill.Controls.Add(tpDrinkCategory);
            tcBill.Controls.Add(tpTable);
            tcBill.Controls.Add(tpAccount);
            tcBill.Location = new Point(13, 10);
            tcBill.Name = "tcBill";
            tcBill.SelectedIndex = 0;
            tcBill.Size = new Size(648, 434);
            tcBill.TabIndex = 0;
            // 
            // tpBill
            // 
            tpBill.Controls.Add(panel3);
            tpBill.Controls.Add(panel4);
            tpBill.Location = new Point(4, 24);
            tpBill.Name = "tpBill";
            tpBill.Padding = new Padding(3);
            tpBill.Size = new Size(640, 406);
            tpBill.TabIndex = 0;
            tpBill.Text = "Doanh thu";
            tpBill.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            panel3.Controls.Add(btnViewBill);
            panel3.Controls.Add(dtpkToDate);
            panel3.Controls.Add(label2);
            panel3.Controls.Add(dtpkFromDate);
            panel3.Location = new Point(5, 6);
            panel3.Name = "panel3";
            panel3.Size = new Size(631, 39);
            panel3.TabIndex = 3;
            // 
            // btnViewBill
            // 
            btnViewBill.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnViewBill.Location = new Point(553, 3);
            btnViewBill.Name = "btnViewBill";
            btnViewBill.Size = new Size(75, 23);
            btnViewBill.TabIndex = 6;
            btnViewBill.Text = "Thống kê";
            btnViewBill.UseVisualStyleBackColor = true;
            btnViewBill.Click += btnViewBill_Click_1;
            // 
            // dtpkToDate
            // 
            dtpkToDate.Location = new Point(276, 3);
            dtpkToDate.Name = "dtpkToDate";
            dtpkToDate.Size = new Size(198, 23);
            dtpkToDate.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(222, 9);
            label2.Name = "label2";
            label2.Size = new Size(31, 15);
            label2.TabIndex = 1;
            label2.Text = "Đến:";
            // 
            // dtpkFromDate
            // 
            dtpkFromDate.Location = new Point(3, 3);
            dtpkFromDate.Name = "dtpkFromDate";
            dtpkFromDate.Size = new Size(198, 23);
            dtpkFromDate.TabIndex = 0;
            // 
            // panel4
            // 
            panel4.Controls.Add(dtgvBill);
            panel4.Location = new Point(5, 51);
            panel4.Name = "panel4";
            panel4.Size = new Size(631, 350);
            panel4.TabIndex = 2;
            // 
            // dtgvBill
            // 
            dtgvBill.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dtgvBill.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgvBill.Location = new Point(5, 4);
            dtgvBill.Name = "dtgvBill";
            dtgvBill.Size = new Size(624, 342);
            dtgvBill.TabIndex = 0;
            // 
            // tpDrink
            // 
            tpDrink.Controls.Add(panel6);
            tpDrink.Controls.Add(panel5);
            tpDrink.Controls.Add(panel2);
            tpDrink.Controls.Add(panel1);
            tpDrink.Location = new Point(4, 24);
            tpDrink.Name = "tpDrink";
            tpDrink.Padding = new Padding(3);
            tpDrink.Size = new Size(640, 406);
            tpDrink.TabIndex = 1;
            tpDrink.Text = "Thức uống";
            tpDrink.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            panel6.Controls.Add(txbSearchName);
            panel6.Controls.Add(btnSearchDrink);
            panel6.Location = new Point(366, 5);
            panel6.Name = "panel6";
            panel6.Size = new Size(271, 40);
            panel6.TabIndex = 3;
            // 
            // txbSearchName
            // 
            txbSearchName.Location = new Point(3, 10);
            txbSearchName.Name = "txbSearchName";
            txbSearchName.Size = new Size(164, 23);
            txbSearchName.TabIndex = 8;
            // 
            // btnSearchDrink
            // 
            btnSearchDrink.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSearchDrink.Location = new Point(187, 3);
            btnSearchDrink.Name = "btnSearchDrink";
            btnSearchDrink.Size = new Size(81, 34);
            btnSearchDrink.TabIndex = 7;
            btnSearchDrink.Text = "Tìm";
            btnSearchDrink.UseVisualStyleBackColor = true;
            btnSearchDrink.Click += btnSearchDrink_Click;
            // 
            // panel5
            // 
            panel5.Controls.Add(panel10);
            panel5.Controls.Add(panel9);
            panel5.Controls.Add(panel8);
            panel5.Controls.Add(panel7);
            panel5.Location = new Point(365, 51);
            panel5.Name = "panel5";
            panel5.Size = new Size(272, 350);
            panel5.TabIndex = 2;
            // 
            // panel10
            // 
            panel10.Controls.Add(nmDrinkPrice);
            panel10.Controls.Add(label5);
            panel10.Location = new Point(3, 158);
            panel10.Name = "panel10";
            panel10.Size = new Size(265, 31);
            panel10.TabIndex = 5;
            // 
            // nmDrinkPrice
            // 
            nmDrinkPrice.Location = new Point(94, 3);
            nmDrinkPrice.Maximum = new decimal(new int[] { 100000000, 0, 0, 0 });
            nmDrinkPrice.Name = "nmDrinkPrice";
            nmDrinkPrice.Size = new Size(169, 23);
            nmDrinkPrice.TabIndex = 1;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(3, 3);
            label5.Name = "label5";
            label5.Size = new Size(36, 20);
            label5.TabIndex = 0;
            label5.Text = "Giá:";
            // 
            // panel9
            // 
            panel9.Controls.Add(cbDrinkCategory);
            panel9.Controls.Add(label4);
            panel9.Location = new Point(3, 112);
            panel9.Name = "panel9";
            panel9.Size = new Size(265, 31);
            panel9.TabIndex = 5;
            // 
            // cbDrinkCategory
            // 
            cbDrinkCategory.FormattingEnabled = true;
            cbDrinkCategory.Location = new Point(94, 3);
            cbDrinkCategory.Name = "cbDrinkCategory";
            cbDrinkCategory.Size = new Size(169, 23);
            cbDrinkCategory.TabIndex = 1;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(3, 3);
            label4.Name = "label4";
            label4.Size = new Size(84, 20);
            label4.TabIndex = 0;
            label4.Text = "Danh mục:";
            // 
            // panel8
            // 
            panel8.Controls.Add(txbDrinkName);
            panel8.Controls.Add(label3);
            panel8.Location = new Point(4, 65);
            panel8.Name = "panel8";
            panel8.Size = new Size(265, 31);
            panel8.TabIndex = 4;
            // 
            // txbDrinkName
            // 
            txbDrinkName.Location = new Point(93, 3);
            txbDrinkName.Name = "txbDrinkName";
            txbDrinkName.Size = new Size(169, 23);
            txbDrinkName.TabIndex = 1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(3, 3);
            label3.Name = "label3";
            label3.Size = new Size(74, 20);
            label3.TabIndex = 0;
            label3.Text = "Tên món:";
            // 
            // panel7
            // 
            panel7.Controls.Add(txbDrinkID);
            panel7.Controls.Add(label1);
            panel7.Location = new Point(4, 18);
            panel7.Name = "panel7";
            panel7.Size = new Size(265, 31);
            panel7.TabIndex = 3;
            // 
            // txbDrinkID
            // 
            txbDrinkID.Location = new Point(93, 3);
            txbDrinkID.Name = "txbDrinkID";
            txbDrinkID.ReadOnly = true;
            txbDrinkID.Size = new Size(169, 23);
            txbDrinkID.TabIndex = 1;
            txbDrinkID.TextChanged += txbDrinkID_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(3, 3);
            label1.Name = "label1";
            label1.Size = new Size(29, 20);
            label1.TabIndex = 0;
            label1.Text = "ID:";
            // 
            // panel2
            // 
            panel2.Controls.Add(btnShowDrink);
            panel2.Controls.Add(btnEditDrink);
            panel2.Controls.Add(btnDeleteDrink);
            panel2.Controls.Add(btnAddDrink);
            panel2.Location = new Point(5, 5);
            panel2.Name = "panel2";
            panel2.Size = new Size(351, 40);
            panel2.TabIndex = 1;
            // 
            // btnShowDrink
            // 
            btnShowDrink.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnShowDrink.Location = new Point(267, 3);
            btnShowDrink.Name = "btnShowDrink";
            btnShowDrink.Size = new Size(81, 34);
            btnShowDrink.TabIndex = 6;
            btnShowDrink.Text = "Xem";
            btnShowDrink.UseVisualStyleBackColor = true;
            btnShowDrink.Click += btnShowDrink_Click;
            // 
            // btnEditDrink
            // 
            btnEditDrink.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEditDrink.Location = new Point(180, 3);
            btnEditDrink.Name = "btnEditDrink";
            btnEditDrink.Size = new Size(81, 34);
            btnEditDrink.TabIndex = 5;
            btnEditDrink.Text = "Sửa";
            btnEditDrink.UseVisualStyleBackColor = true;
            btnEditDrink.Click += btnEditDrink_Click;
            // 
            // btnDeleteDrink
            // 
            btnDeleteDrink.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDeleteDrink.Location = new Point(90, 3);
            btnDeleteDrink.Name = "btnDeleteDrink";
            btnDeleteDrink.Size = new Size(81, 34);
            btnDeleteDrink.TabIndex = 4;
            btnDeleteDrink.Text = "Xoá";
            btnDeleteDrink.UseVisualStyleBackColor = true;
            btnDeleteDrink.Click += btnDeleteDrink_Click;
            // 
            // btnAddDrink
            // 
            btnAddDrink.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAddDrink.Location = new Point(3, 3);
            btnAddDrink.Name = "btnAddDrink";
            btnAddDrink.Size = new Size(81, 34);
            btnAddDrink.TabIndex = 3;
            btnAddDrink.Text = "Thêm món";
            btnAddDrink.UseVisualStyleBackColor = true;
            btnAddDrink.Click += btnAddDrink_Click;
            // 
            // panel1
            // 
            panel1.Controls.Add(dtgvDrink);
            panel1.Location = new Point(5, 51);
            panel1.Name = "panel1";
            panel1.Size = new Size(351, 350);
            panel1.TabIndex = 0;
            // 
            // dtgvDrink
            // 
            dtgvDrink.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgvDrink.Location = new Point(4, 3);
            dtgvDrink.Name = "dtgvDrink";
            dtgvDrink.Size = new Size(344, 344);
            dtgvDrink.TabIndex = 0;
            // 
            // tpDrinkCategory
            // 
            tpDrinkCategory.Controls.Add(panel12);
            tpDrinkCategory.Controls.Add(panel17);
            tpDrinkCategory.Controls.Add(panel18);
            tpDrinkCategory.Location = new Point(4, 24);
            tpDrinkCategory.Name = "tpDrinkCategory";
            tpDrinkCategory.Padding = new Padding(3);
            tpDrinkCategory.Size = new Size(640, 406);
            tpDrinkCategory.TabIndex = 2;
            tpDrinkCategory.Text = "Danh mục";
            tpDrinkCategory.UseVisualStyleBackColor = true;
            // 
            // panel12
            // 
            panel12.Controls.Add(panel15);
            panel12.Controls.Add(panel16);
            panel12.Location = new Point(364, 51);
            panel12.Name = "panel12";
            panel12.Size = new Size(272, 350);
            panel12.TabIndex = 6;
            // 
            // panel15
            // 
            panel15.Controls.Add(txbCategoryName);
            panel15.Controls.Add(label8);
            panel15.Location = new Point(4, 65);
            panel15.Name = "panel15";
            panel15.Size = new Size(265, 31);
            panel15.TabIndex = 4;
            // 
            // txbCategoryName
            // 
            txbCategoryName.Location = new Point(116, 3);
            txbCategoryName.Name = "txbCategoryName";
            txbCategoryName.Size = new Size(146, 23);
            txbCategoryName.TabIndex = 1;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(3, 3);
            label8.Name = "label8";
            label8.Size = new Size(111, 20);
            label8.TabIndex = 0;
            label8.Text = "Tên danh mục:";
            // 
            // panel16
            // 
            panel16.Controls.Add(txbCategoryID);
            panel16.Controls.Add(label9);
            panel16.Location = new Point(4, 18);
            panel16.Name = "panel16";
            panel16.Size = new Size(265, 31);
            panel16.TabIndex = 3;
            // 
            // txbCategoryID
            // 
            txbCategoryID.Location = new Point(116, 3);
            txbCategoryID.Name = "txbCategoryID";
            txbCategoryID.ReadOnly = true;
            txbCategoryID.Size = new Size(146, 23);
            txbCategoryID.TabIndex = 1;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(3, 3);
            label9.Name = "label9";
            label9.Size = new Size(29, 20);
            label9.TabIndex = 0;
            label9.Text = "ID:";
            // 
            // panel17
            // 
            panel17.Controls.Add(btnShowCategory);
            panel17.Controls.Add(btnEditCategory);
            panel17.Controls.Add(btnDeleteCategory);
            panel17.Controls.Add(btnAddCategory);
            panel17.Location = new Point(4, 5);
            panel17.Name = "panel17";
            panel17.Size = new Size(351, 40);
            panel17.TabIndex = 5;
            // 
            // btnShowCategory
            // 
            btnShowCategory.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnShowCategory.Location = new Point(267, 3);
            btnShowCategory.Name = "btnShowCategory";
            btnShowCategory.Size = new Size(81, 34);
            btnShowCategory.TabIndex = 6;
            btnShowCategory.Text = "Xem";
            btnShowCategory.UseVisualStyleBackColor = true;
            btnShowCategory.Click += btnShowCategory_Click;
            // 
            // btnEditCategory
            // 
            btnEditCategory.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEditCategory.Location = new Point(180, 3);
            btnEditCategory.Name = "btnEditCategory";
            btnEditCategory.Size = new Size(81, 34);
            btnEditCategory.TabIndex = 5;
            btnEditCategory.Text = "Sửa";
            btnEditCategory.UseVisualStyleBackColor = true;
            btnEditCategory.Click += btnEditCategory_Click;
            // 
            // btnDeleteCategory
            // 
            btnDeleteCategory.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDeleteCategory.Location = new Point(90, 3);
            btnDeleteCategory.Name = "btnDeleteCategory";
            btnDeleteCategory.Size = new Size(81, 34);
            btnDeleteCategory.TabIndex = 4;
            btnDeleteCategory.Text = "Xoá";
            btnDeleteCategory.UseVisualStyleBackColor = true;
            btnDeleteCategory.Click += btnDeleteCategory_Click;
            // 
            // btnAddCategory
            // 
            btnAddCategory.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAddCategory.Location = new Point(3, 3);
            btnAddCategory.Name = "btnAddCategory";
            btnAddCategory.Size = new Size(81, 34);
            btnAddCategory.TabIndex = 3;
            btnAddCategory.Text = "Thêm";
            btnAddCategory.UseVisualStyleBackColor = true;
            btnAddCategory.Click += btnAddCategory_Click;
            // 
            // panel18
            // 
            panel18.Controls.Add(dtgvCategory);
            panel18.Location = new Point(4, 51);
            panel18.Name = "panel18";
            panel18.Size = new Size(351, 350);
            panel18.TabIndex = 4;
            // 
            // dtgvCategory
            // 
            dtgvCategory.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgvCategory.Location = new Point(4, 3);
            dtgvCategory.Name = "dtgvCategory";
            dtgvCategory.Size = new Size(344, 344);
            dtgvCategory.TabIndex = 0;
            // 
            // tpTable
            // 
            tpTable.Controls.Add(panel11);
            tpTable.Controls.Add(panel19);
            tpTable.Controls.Add(panel20);
            tpTable.Location = new Point(4, 24);
            tpTable.Name = "tpTable";
            tpTable.Padding = new Padding(3);
            tpTable.Size = new Size(640, 406);
            tpTable.TabIndex = 3;
            tpTable.Text = "Bàn";
            tpTable.UseVisualStyleBackColor = true;
            // 
            // panel11
            // 
            panel11.Controls.Add(panel21);
            panel11.Controls.Add(panel13);
            panel11.Controls.Add(panel14);
            panel11.Location = new Point(364, 51);
            panel11.Name = "panel11";
            panel11.Size = new Size(272, 350);
            panel11.TabIndex = 9;
            // 
            // panel21
            // 
            panel21.Controls.Add(txbTableStatus);
            panel21.Controls.Add(label10);
            panel21.Location = new Point(4, 113);
            panel21.Name = "panel21";
            panel21.Size = new Size(265, 31);
            panel21.TabIndex = 5;
            // 
            // txbTableStatus
            // 
            txbTableStatus.Location = new Point(102, 3);
            txbTableStatus.Name = "txbTableStatus";
            txbTableStatus.ReadOnly = true;
            txbTableStatus.Size = new Size(160, 23);
            txbTableStatus.TabIndex = 1;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.Location = new Point(3, 3);
            label10.Name = "label10";
            label10.Size = new Size(84, 20);
            label10.TabIndex = 0;
            label10.Text = "Trạng thái:";
            // 
            // panel13
            // 
            panel13.Controls.Add(txbTableName);
            panel13.Controls.Add(label6);
            panel13.Location = new Point(4, 65);
            panel13.Name = "panel13";
            panel13.Size = new Size(265, 31);
            panel13.TabIndex = 4;
            // 
            // txbTableName
            // 
            txbTableName.Location = new Point(102, 3);
            txbTableName.Name = "txbTableName";
            txbTableName.Size = new Size(160, 23);
            txbTableName.TabIndex = 1;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(3, 3);
            label6.Name = "label6";
            label6.Size = new Size(68, 20);
            label6.TabIndex = 0;
            label6.Text = "Tên bàn:";
            // 
            // panel14
            // 
            panel14.Controls.Add(txbTableID);
            panel14.Controls.Add(label7);
            panel14.Location = new Point(4, 18);
            panel14.Name = "panel14";
            panel14.Size = new Size(265, 31);
            panel14.TabIndex = 3;
            // 
            // txbTableID
            // 
            txbTableID.Location = new Point(102, 3);
            txbTableID.Name = "txbTableID";
            txbTableID.ReadOnly = true;
            txbTableID.Size = new Size(160, 23);
            txbTableID.TabIndex = 1;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(3, 3);
            label7.Name = "label7";
            label7.Size = new Size(29, 20);
            label7.TabIndex = 0;
            label7.Text = "ID:";
            // 
            // panel19
            // 
            panel19.Controls.Add(btnShowTable);
            panel19.Controls.Add(btnEditTable);
            panel19.Controls.Add(btnDeleteTable);
            panel19.Controls.Add(btnAddTable);
            panel19.Location = new Point(4, 5);
            panel19.Name = "panel19";
            panel19.Size = new Size(351, 40);
            panel19.TabIndex = 8;
            // 
            // btnShowTable
            // 
            btnShowTable.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnShowTable.Location = new Point(267, 3);
            btnShowTable.Name = "btnShowTable";
            btnShowTable.Size = new Size(81, 34);
            btnShowTable.TabIndex = 6;
            btnShowTable.Text = "Xem";
            btnShowTable.UseVisualStyleBackColor = true;
            btnShowTable.Click += btnShowTable_Click;
            // 
            // btnEditTable
            // 
            btnEditTable.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEditTable.Location = new Point(180, 3);
            btnEditTable.Name = "btnEditTable";
            btnEditTable.Size = new Size(81, 34);
            btnEditTable.TabIndex = 5;
            btnEditTable.Text = "Sửa";
            btnEditTable.UseVisualStyleBackColor = true;
            btnEditTable.Click += btnEditTable_Click;
            // 
            // btnDeleteTable
            // 
            btnDeleteTable.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDeleteTable.Location = new Point(90, 3);
            btnDeleteTable.Name = "btnDeleteTable";
            btnDeleteTable.Size = new Size(81, 34);
            btnDeleteTable.TabIndex = 4;
            btnDeleteTable.Text = "Xoá";
            btnDeleteTable.UseVisualStyleBackColor = true;
            btnDeleteTable.Click += btnDeleteTable_Click;
            // 
            // btnAddTable
            // 
            btnAddTable.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAddTable.Location = new Point(3, 3);
            btnAddTable.Name = "btnAddTable";
            btnAddTable.Size = new Size(81, 34);
            btnAddTable.TabIndex = 3;
            btnAddTable.Text = "Thêm";
            btnAddTable.UseVisualStyleBackColor = true;
            btnAddTable.Click += btnAddTable_Click;
            // 
            // panel20
            // 
            panel20.Controls.Add(dtgvTable);
            panel20.Location = new Point(4, 51);
            panel20.Name = "panel20";
            panel20.Size = new Size(351, 350);
            panel20.TabIndex = 7;
            // 
            // dtgvTable
            // 
            dtgvTable.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgvTable.Location = new Point(4, 3);
            dtgvTable.Name = "dtgvTable";
            dtgvTable.Size = new Size(344, 344);
            dtgvTable.TabIndex = 0;
            // 
            // tpAccount
            // 
            tpAccount.Controls.Add(panel22);
            tpAccount.Controls.Add(panel26);
            tpAccount.Controls.Add(panel27);
            tpAccount.Location = new Point(4, 24);
            tpAccount.Name = "tpAccount";
            tpAccount.Padding = new Padding(3);
            tpAccount.Size = new Size(640, 406);
            tpAccount.TabIndex = 4;
            tpAccount.Text = "Tài khoản";
            tpAccount.UseVisualStyleBackColor = true;
            // 
            // panel22
            // 
            panel22.Controls.Add(btnResetPass);
            panel22.Controls.Add(panel23);
            panel22.Controls.Add(panel24);
            panel22.Controls.Add(panel25);
            panel22.Location = new Point(364, 51);
            panel22.Name = "panel22";
            panel22.Size = new Size(272, 350);
            panel22.TabIndex = 12;
            // 
            // btnResetPass
            // 
            btnResetPass.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnResetPass.Location = new Point(185, 150);
            btnResetPass.Name = "btnResetPass";
            btnResetPass.Size = new Size(81, 41);
            btnResetPass.TabIndex = 7;
            btnResetPass.Text = "Đặt lại mật khẩu";
            btnResetPass.UseVisualStyleBackColor = true;
            btnResetPass.Click += btnResetPass_Click;
            // 
            // panel23
            // 
            panel23.Controls.Add(numericUpDown1);
            panel23.Controls.Add(label11);
            panel23.Location = new Point(4, 113);
            panel23.Name = "panel23";
            panel23.Size = new Size(265, 31);
            panel23.TabIndex = 5;
            // 
            // numericUpDown1
            // 
            numericUpDown1.Location = new Point(122, 6);
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(140, 23);
            numericUpDown1.TabIndex = 1;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.Location = new Point(3, 3);
            label11.Name = "label11";
            label11.Size = new Size(111, 20);
            label11.TabIndex = 0;
            label11.Text = "Loại tài khoản:";
            // 
            // panel24
            // 
            panel24.Controls.Add(txbDislplayName);
            panel24.Controls.Add(label12);
            panel24.Location = new Point(4, 65);
            panel24.Name = "panel24";
            panel24.Size = new Size(265, 31);
            panel24.TabIndex = 4;
            // 
            // txbDislplayName
            // 
            txbDislplayName.Location = new Point(122, 3);
            txbDislplayName.Name = "txbDislplayName";
            txbDislplayName.Size = new Size(140, 23);
            txbDislplayName.TabIndex = 1;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.Location = new Point(3, 3);
            label12.Name = "label12";
            label12.Size = new Size(95, 20);
            label12.TabIndex = 0;
            label12.Text = "Tên hiển thị:";
            // 
            // panel25
            // 
            panel25.Controls.Add(txbUserName);
            panel25.Controls.Add(label13);
            panel25.Location = new Point(4, 18);
            panel25.Name = "panel25";
            panel25.Size = new Size(265, 31);
            panel25.TabIndex = 3;
            // 
            // txbUserName
            // 
            txbUserName.Location = new Point(122, 3);
            txbUserName.Name = "txbUserName";
            txbUserName.Size = new Size(140, 23);
            txbUserName.TabIndex = 1;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.Location = new Point(3, 3);
            label13.Name = "label13";
            label13.Size = new Size(103, 20);
            label13.TabIndex = 0;
            label13.Text = "Tên tài khoản";
            // 
            // panel26
            // 
            panel26.Controls.Add(btnShowAccount);
            panel26.Controls.Add(btnEditAccount);
            panel26.Controls.Add(btnDeleteAccount);
            panel26.Controls.Add(btnAddAccount);
            panel26.Location = new Point(4, 5);
            panel26.Name = "panel26";
            panel26.Size = new Size(351, 40);
            panel26.TabIndex = 11;
            // 
            // btnShowAccount
            // 
            btnShowAccount.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnShowAccount.Location = new Point(267, 3);
            btnShowAccount.Name = "btnShowAccount";
            btnShowAccount.Size = new Size(81, 34);
            btnShowAccount.TabIndex = 6;
            btnShowAccount.Text = "Xem";
            btnShowAccount.UseVisualStyleBackColor = true;
            btnShowAccount.Click += btnShowAccount_Click;
            // 
            // btnEditAccount
            // 
            btnEditAccount.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEditAccount.Location = new Point(180, 3);
            btnEditAccount.Name = "btnEditAccount";
            btnEditAccount.Size = new Size(81, 34);
            btnEditAccount.TabIndex = 5;
            btnEditAccount.Text = "Sửa";
            btnEditAccount.UseVisualStyleBackColor = true;
            btnEditAccount.Click += btnEditAccount_Click;
            // 
            // btnDeleteAccount
            // 
            btnDeleteAccount.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDeleteAccount.Location = new Point(90, 3);
            btnDeleteAccount.Name = "btnDeleteAccount";
            btnDeleteAccount.Size = new Size(81, 34);
            btnDeleteAccount.TabIndex = 4;
            btnDeleteAccount.Text = "Xoá";
            btnDeleteAccount.UseVisualStyleBackColor = true;
            btnDeleteAccount.Click += btnDeleteAccount_Click;
            // 
            // btnAddAccount
            // 
            btnAddAccount.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAddAccount.Location = new Point(3, 3);
            btnAddAccount.Name = "btnAddAccount";
            btnAddAccount.Size = new Size(81, 34);
            btnAddAccount.TabIndex = 3;
            btnAddAccount.Text = "Thêm";
            btnAddAccount.UseVisualStyleBackColor = true;
            btnAddAccount.Click += btnAddAccount_Click;
            // 
            // panel27
            // 
            panel27.Controls.Add(dtgvAccount);
            panel27.Location = new Point(4, 51);
            panel27.Name = "panel27";
            panel27.Size = new Size(351, 350);
            panel27.TabIndex = 10;
            // 
            // dtgvAccount
            // 
            dtgvAccount.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgvAccount.Location = new Point(4, 3);
            dtgvAccount.Name = "dtgvAccount";
            dtgvAccount.Size = new Size(344, 344);
            dtgvAccount.TabIndex = 0;
            // 
            // fAdmin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(668, 450);
            Controls.Add(tcBill);
            Name = "fAdmin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Admin";
            tcBill.ResumeLayout(false);
            tpBill.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dtgvBill).EndInit();
            tpDrink.ResumeLayout(false);
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            panel5.ResumeLayout(false);
            panel10.ResumeLayout(false);
            panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nmDrinkPrice).EndInit();
            panel9.ResumeLayout(false);
            panel9.PerformLayout();
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            panel2.ResumeLayout(false);
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dtgvDrink).EndInit();
            tpDrinkCategory.ResumeLayout(false);
            panel12.ResumeLayout(false);
            panel15.ResumeLayout(false);
            panel15.PerformLayout();
            panel16.ResumeLayout(false);
            panel16.PerformLayout();
            panel17.ResumeLayout(false);
            panel18.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dtgvCategory).EndInit();
            tpTable.ResumeLayout(false);
            panel11.ResumeLayout(false);
            panel21.ResumeLayout(false);
            panel21.PerformLayout();
            panel13.ResumeLayout(false);
            panel13.PerformLayout();
            panel14.ResumeLayout(false);
            panel14.PerformLayout();
            panel19.ResumeLayout(false);
            panel20.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dtgvTable).EndInit();
            tpAccount.ResumeLayout(false);
            panel22.ResumeLayout(false);
            panel23.ResumeLayout(false);
            panel23.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            panel24.ResumeLayout(false);
            panel24.PerformLayout();
            panel25.ResumeLayout(false);
            panel25.PerformLayout();
            panel26.ResumeLayout(false);
            panel27.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dtgvAccount).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tcBill;
        private TabPage tpBill;
        private TabPage tpDrink;
        private TabPage tpDrinkCategory;
        private TabPage tpTable;
        private TabPage tpAccount;
        private Panel panel3;
        private Button btnViewBill;
        private DateTimePicker dtpkToDate;
        private Label label2;
        private DateTimePicker dtpkFromDate;
        private Panel panel4;
        private DataGridView dtgvBill;
        private Panel panel2;
        private Panel panel1;
        private Panel panel6;
        private Panel panel5;
        private DataGridView dtgvDrink;
        private Button btnShowDrink;
        private Button btnEditDrink;
        private Button btnDeleteDrink;
        private Button btnAddDrink;
        private TextBox txbSearchName;
        private Button btnSearchDrink;
        private Panel panel7;
        private TextBox txbDrinkID;
        private Label label1;
        private Panel panel8;
        private TextBox txbDrinkName;
        private Label label3;
        private Panel panel9;
        private Label label4;
        private Panel panel10;
        private NumericUpDown nmDrinkPrice;
        private Label label5;
        private ComboBox cbDrinkCategory;
        private Panel panel12;
        private Panel panel15;
        private TextBox txbCategoryName;
        private Label label8;
        private Panel panel16;
        private TextBox txbCategoryID;
        private Label label9;
        private Panel panel17;
        private Button btnShowCategory;
        private Button btnEditCategory;
        private Button btnDeleteCategory;
        private Button btnAddCategory;
        private Panel panel18;
        private DataGridView dtgvCategory;
        private Panel panel11;
        private Panel panel21;
        private Label label10;
        private Panel panel13;
        private TextBox txbTableName;
        private Label label6;
        private Panel panel14;
        private TextBox txbTableID;
        private Label label7;
        private Panel panel19;
        private Button btnShowTable;
        private Button btnEditTable;
        private Button btnDeleteTable;
        private Button btnAddTable;
        private Panel panel20;
        private DataGridView dtgvTable;
        private Panel panel22;
        private Panel panel23;
        private Label label11;
        private Panel panel24;
        private TextBox txbDislplayName;
        private Label label12;
        private Panel panel25;
        private TextBox txbUserName;
        private Label label13;
        private Panel panel26;
        private Button btnShowAccount;
        private Button btnEditAccount;
        private Button btnDeleteAccount;
        private Button btnAddAccount;
        private Panel panel27;
        private DataGridView dtgvAccount;
        private Button btnResetPass;
        private NumericUpDown numericUpDown1;
        private TextBox txbTableStatus;
    }
}